declare module "@salesforce/apex/OrderController.getRecordId" {
  export default function getRecordId(): Promise<any>;
}
declare module "@salesforce/apex/OrderController.displayProducts" {
  export default function displayProducts(param: {searchValue: any, priceBookId: any, searchDomain: any, lowlimit: any, uplimit: any}): Promise<any>;
}
declare module "@salesforce/apex/OrderController.insertOrderProducts" {
  export default function insertOrderProducts(param: {selectedProductsList: any, priceBookId: any, orderId: any}): Promise<any>;
}
