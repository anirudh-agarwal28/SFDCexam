declare module "@salesforce/apex/OrderDisplayController.getAccountOrder" {
  export default function getAccountOrder(param: {createdOrderId: any}): Promise<any>;
}
declare module "@salesforce/apex/OrderDisplayController.updateOrderStage" {
  export default function updateOrderStage(param: {createdOrderId: any}): Promise<any>;
}
