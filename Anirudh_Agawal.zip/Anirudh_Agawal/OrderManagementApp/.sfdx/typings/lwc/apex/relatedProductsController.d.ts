declare module "@salesforce/apex/relatedProductsController.getRecordData" {
  export default function getRecordData(param: {orderId: any}): Promise<any>;
}
