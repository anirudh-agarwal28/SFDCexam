declare module "@salesforce/apex/OrderSummaryController.getAccOrd" {
  export default function getAccOrd(param: {createdOrderId: any}): Promise<any>;
}
declare module "@salesforce/apex/OrderSummaryController.updateOrder" {
  export default function updateOrder(param: {createdOrderId: any}): Promise<any>;
}
