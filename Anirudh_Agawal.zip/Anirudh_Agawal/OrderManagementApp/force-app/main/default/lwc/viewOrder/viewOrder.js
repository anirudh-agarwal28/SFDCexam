import {
    LightningElement,
    api,
    track
} from 'lwc';

import getRecordData from '@salesforce/apex/relatedProductsController.getRecordData';

export default class View extends LightningElement {

    @api recordId;
    @api objectApiName;
    productsList = [];
    selects;

    connectedCallback() {
        
        getRecordData({
                orderId: this.recordId
            })
            .then(result => {
                console.log(JSON.parse(result));
                this.productsList = JSON.parse(result);
            })
            .catch(error => {
                console.log(error);
            });
    }
}