import { LightningElement , track } from 'lwc';
import displayProducts from '@salesforce/apex/OrderController.displayProducts';
import getRecordId from '@salesforce/apex/OrderController.getRecordId';
import insertOrderProducts from '@salesforce/apex/OrderController.insertOrderProducts';
import getAccountOrder from '@salesforce/apex/OrderDisplayController.getAccountOrder';
import updateOrderStage from '@salesforce/apex/OrderDisplayController.updateOrderStage';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class Ordermanage extends LightningElement {
    @track searchDomainValue = '';
    showSummary = false;
    showSummaryButton = false;
    @track accountOrderDetail = [];
    selects;
    recordId = '';
    orderCreated = false;
    error;
    lowerLimit = '';
    upperLimit = '';
    searchText = '';
    priceBookId;
    productList;
    showSearchBar = false;
    showFinalTable = false;
    selectedProductsTable = false;
    showSearchList = false;
    minmax = false;
    selectedProductsList = [];
    showSearchOption = false;
    get options() {
        return [{
                label: 'Product Name',
                value: 'Product Name'
            },
            {
                label: 'Brand',
                value: 'Brand'
            },
            {
                label: 'Price',
                value: 'Price'
            }
        ];
    }
    handleSuccess(event) {
        alert('Add your Products by below domains');
        this.orderCreated = true;
        if (this.orderCreated) {
            getRecordId()
                .then(result => {
                    this.recordId = result;
                    console.log(this.recordId);
                })
        }

        this.showSearchOption = true;
    }

    getMinValue(event) {
        console.log(event.target.value);
        this.lowerLimit = event.target.value;
    }
    getMaxValue(event) {
        this.upperLimit = event.target.value;
    }
    handleDomain(event) {
        this.searchDomainValue = event.detail.value;
        console.log(this.searchDomainValue);
        if (this.searchDomainValue == 'Price') {

            this.minmax = true;
            this.showSearchBar = false;
        } else {
            this.showSearchBar = true;
            this.minmax = false;
        }
    }

    handleSearch(event) {
        this.searchText = event.detail;
        console.log(event.target.name);
        if (event.target.name == 'sbp') {
            displayProducts({
                    searchValue: '',
                    priceBookId: '01s2w000004YsJPAA0',
                    searchDomain: this.searchDomainValue,
                    lowlimit: this.lowerLimit,
                    uplimit: this.upperLimit
                })
                .then(result => {
                    this.productList = JSON.parse(result);
                    console.log(this.productList);
                });
            this.showSearchList = true;
        } else if (event.detail.length != 0) {
            console.log('in testing');
            displayProducts({
                    searchValue: event.target.value,
                    priceBookId: '01s2w000004YsJPAA0',
                    searchDomain: this.searchDomainValue,
                    lowlimit: this.lowerLimit,
                    uplimit: this.upperLimit
                })
                .then(result => {
                    this.productList = JSON.parse(result);
                    console.log(this.productList);
                });
            this.showSearchList = true;
        } else {
            this.showSearchList = false;
        }
    }

    addNewProduct(event) {
        var addId = event.target.value;
        this.selectedProductsTable = false;
        var selects = new Object();
        for (var prod of this.productList) {
            if (prod.Id == addId) {
                console.log('to check listprice');
                console.log(prod.ListPrice);
                selects.Id = prod.Id;
                selects.ProductCode = prod.ProductCode;
                selects.Name = prod.Name;
                //selects.Brand__c = prod.Brand__c;
                selects.Brand = prod.Brand__c;
                selects.StockQuantity = prod.Stock_Quantity__c;
                selects.Quantity = 1;
                selects.UnitPrice = 0;
                selects.ListPrice = prod.ListPrice;
                selects.PriceBookEntryId = prod.PriceBookEntryId;
                console.log('to check selects unit price');
                console.log(selects.UnitPrice);
                console.log('pricebookentry id issue');
                console.log(selects.PriceBookEntryId);

            }
            console.log(selects);
            if (!this.selectedProductsList.some(item => item.Id === selects.Id)) {
                this.selectedProductsList.push(selects);
                console.log(this.selectedProductsList);
            }
            //this.showSearchList=false;
            this.selectedProductsTable = true;
        }
        this.showFinalTable = false;
    }

    handleQuantity(event) {
        var i = -1;
        //var fieldId;
        for (var prod of this.selectedProductsList) {
            i++;
            if (prod.Id == event.target.name) {
                // fieldId=prod.Id;
                break;
            }
        }
        this.selectedProductsList[i].Quantity = event.target.value;
    }

    handleDiscount(event) {
        var i = -1;
        for (var prod of this.selectedProductsList) {
            i++;
            if (prod.Id == event.target.name) {
                break;
            }
        }
        this.selectedProductsList[i].Discount = event.target.value;
    }

    removeItem(event) {
        var i = -1;
        for (var prod of this.selectedProductsList) {
            i++;
            if (prod.Id == event.target.value) {
                break;

            }
        }
        this.selectedProductsList.splice(i, 1);
        this.selectedProductsTable = false;
        this.selectedProductsTable = true;

    }

    saveItems(event) {
        console.log('In saveItems----------');
        console.log('the event is ' + event);
        console.log('the choosen products are ' + this.selectedProductsList);
        for (var prod of this.selectedProductsList) {
            var selects = new Object();
            if (prod.Quantity > 10) {
                selects.Id = prod.Id;
                selects.Name = prod.Name;
                selects.ProductCode = prod.ProductCode;
                selects.Brand = prod.Brand;
                selects.StockQuantity = prod.StockQuantity;
                selects.Quantity = '1';
                selects.ListPrice = 0;
                selects.UnitPrice = 0;
                selects.Discount = 100;
                selects.PriceBookEntryId = prod.PriceBookEntryId;
                this.selectedProductsList.push(selects);
            }
            if (prod.Discount >= 0 && prod.Discount <= 100) {
                prod.UnitPrice = prod.ListPrice - (prod.ListPrice * prod.Discount / 100);
            } else {
                prod.UnitPrice = prod.ListPrice;
            }

        }
        console.log(this.selectedProductsList);
        console.log(JSON.stringify(this.selectedProductsList));

        insertOrderProducts({
                selectedProductsList: JSON.stringify(this.selectedProductsList),
                priceBookId: '01s2w000004YsJPAA0',
                orderId: this.recordId
            })
            .then(result => {
                console.log('Order Id : ' + result);
            })
            .catch(error => {
                console.log(error);
            });

        this.showFinalTable = false;
        this.selectedProductsTable = false;
        this.showSummaryButton = true;

    }

    clearSearchField(event) {
        this.searchText = '';
    }
    displaySummary(event) {
        this.showSummary = true;
        console.log('in get Summary');
        console.log(this.recordId);
        getAccountOrder({
                createdOrderId: this.recordId
            })
            .then(result => {
                this.accountOrderDetail = result;
                console.log(this.accountOrderDetail);
            })
            .catch(error => {
                console.log(error);
            });
        this.showSearchList = false;
        this.showSearchBar = false;
    }

    handleConfirm(event) {
        console.log('handleConfirm');
        console.log(this.recordId);

        const event1 = new ShowToastEvent({
            title: 'Order Created',
            message: 'Order Has Been Successfully Created',
        });
        this.dispatchEvent(event1);
        location.reload();
    }
    handleCancel(event) {
        console.log(this.recordId);

        updateOrderStage({
                createdOrderId: this.recordId
            })
            .then(result => {
                this.accountOrderDetail = result;
                console.log(this.accountOrderDetail);
            })
            .catch(error => {
                console.log(error);
            });

        console.log(this.recordId);
        const event2 = new ShowToastEvent({
            title: 'Order Cancelled',
            message: 'Order Has Been Cancelled',
        });
        this.dispatchEvent(event2);
        location.reload();

    }
}